npm i -D eslint eslint-config-standard eslint-plugin-vue
