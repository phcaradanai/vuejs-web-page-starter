<route lang="yaml">
meta:
  layout: default
</route>

<template>
  <div class="w-200 m-auto">
    <div class="flex gap-2">
      <button class="w-20 border-1 bg-gray-200" @click="motorOpen">
        OPEN
      </button>
      <button class="w-20 border-1 bg-gray-200" @click="motorSelect">
        SELECT
      </button>
    </div>
    <textarea v-model="msg" rows="10"></textarea>
  </div>
</template>

<script>
export default {
  data() {
    return {
      msg: '',
    }
  },
  methods: {
    motorOpen() {
      let s = Object.keys(window.XenKiosk).join('\n')
      this.msg = s
      window.XenKiosk.motorOpen('dev/ttyS1')
    },
    motorSelect() {
      window.XenKiosk.motorSelect(0, 0, 3, 111)
    },
  },
}
</script>
